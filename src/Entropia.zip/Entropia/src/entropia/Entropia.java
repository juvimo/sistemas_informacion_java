package entropia;
import java.util.Scanner;

public class Entropia {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("SISTEMA DE ENTROPIA Y PROBABILIDADES");
            System.out.println("1. Calcular Entropia de Shannon (desde probabilidades)");
            System.out.println("2. Calcular Entropia Conjunta H(X,Y) y Condicional H(Y|X)");
            System.out.println("3. Salir");
            System.out.print("Selecciona una opcion (1-3): ");
            
            opcion = sc.nextInt();
            sc.nextLine();

            switch (opcion) {
                case 1:
                    calcularEntropiaProbabilidades(sc);
                    break;
                case 2:
                    calcularEntropiaConjunta(sc);
                    break;
                case 3:
                    System.out.println("Saliendo del sistema. ¡Hasta luego!");
                    break;
                default:
                    System.out.println("Opcion no valida. Intenta de nuevo.");
            }
        } while (opcion != 3);

        sc.close();
    }

    // --- OPCION 1: ENTROPIA DESDE VECTOR DE PROBABILIDADES ---
    public static void calcularEntropiaProbabilidades(Scanner sc) {
        System.out.println("\n--- 1. ENTROPIA DESDE VECTOR DE PROBABILIDADES ---");
        System.out.print("Introduce el numero de eventos o simbolos (n): ");
        int n = sc.nextInt();

        if (n <= 0) {
            System.out.println("El numero de eventos debe ser mayor a 0.");
            return;
        }

        double[] probabilidades = new double[n];
        double sumaProbabilidades = 0.0;

        System.out.println("Introduce la probabilidad de cada evento:");
        for (int i = 0; i < n; i++) {
            System.out.print("Probabilidad P(x" + (i + 1) + "): ");
            probabilidades[i] = sc.nextDouble();

            if (probabilidades[i] < 0 || probabilidades[i] > 1) {
                System.out.println("Error: La probabilidad debe estar entre 0 y 1.");
                return;
            }
            sumaProbabilidades += probabilidades[i];
        }

        if (Math.abs(sumaProbabilidades - 1.0) > 0.001) {
            System.out.printf("\nAdvertencia: La suma es %.4f (deberia ser 1.0).%n", sumaProbabilidades);
        }

        double entropia = 0.0;
        for (double p : probabilidades) {
            if (p > 0) {
                entropia -= p * (Math.log(p) / Math.log(2));
            }
        }

        System.out.println("\n--- RESULTADO ---");
        System.out.printf("Suma total de probabilidades: %.4f%n", sumaProbabilidades);
        System.out.printf("Entropia de Shannon H(X): %.4f bits/simbolo%n", entropia);
    }

    // --- OPCION 2: ENTROPIA CONJUNTA Y CONDICIONAL ---
    public static void calcularEntropiaConjunta(Scanner sc) {
        System.out.println("\n--- 2. ENTROPIA CONJUNTA Y CONDICIONAL ---");
        System.out.print("Introduce el numero de estados de X (filas): ");
        int filas = sc.nextInt();
        System.out.print("Introduce el numero de estados de Y (columnas): ");
        int columnas = sc.nextInt();

        if (filas <= 0 || columnas <= 0) {
            System.out.println("Las dimensiones deben ser mayores a 0.");
            return;
        }

        double[][] pxy = new double[filas][columnas];
        double sumaTotal = 0.0;

        System.out.println("Introduce los valores de la matriz P(X,Y):");
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                System.out.print("P(X=" + (i + 1) + ", Y=" + (j + 1) + "): ");
                pxy[i][j] = sc.nextDouble();

                if (pxy[i][j] < 0 || pxy[i][j] > 1) {
                    System.out.println("Error: Las probabilidades deben estar entre 0 y 1.");
                    return;
                }
                sumaTotal += pxy[i][j];
            }
        }

        if (Math.abs(sumaTotal - 1.0) > 0.001) {
            System.out.printf("Advertencia: La suma total de la matriz es %.4f (deberia ser 1.0)", sumaTotal);
        }

        // Calcular marginales de X
        double[] px = new double[filas];
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                px[i] += pxy[i][j];
            }
        }

        // Calcular Entropía Conjunta H(X,Y)
        double hxy = 0.0;
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                double p = pxy[i][j];
                if (p > 0) {
                    hxy -= p * (Math.log(p) / Math.log(2));
                }
            }
        }

        // Calcular Entropía Condicional H(Y|X)
        double hyx = 0.0;
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                double pJoint = pxy[i][j];
                if (pJoint > 0 && px[i] > 0) {
                    double pCond = pJoint / px[i];
                    hyx -= pJoint * (Math.log(pCond) / Math.log(2));
                }
            }
        }

        System.out.println("\n--- RESULTADOS ---");
        System.out.printf("Entropia Conjunta H(X,Y):      %.4f bits%n", hxy);
        System.out.printf("Entropia Condicional H(Y|X):   %.4f bits%n", hyx);
    }
}