package red.solomon;
import java.util.Scanner;

    public class RedSolomon {
        public static void main(String[] args) {
            Scanner sc = new Scanner(System.in);
            
        System.out.println("CODIFICACION RED-SOLOMON");
        System.out.println("Introduce los numeros del mensaje:");
        System.out.println("Ingrese el valor de A: ");
        double a = sc.nextDouble();
        System.out.println("Ingrese el valor de B: ");
        double b = sc.nextDouble();
        System.out.println("Ingrese el valor de C: ");
        double c = sc.nextDouble();
        
        double d = (2*a)+(b)+(3*c);
        double e = (a)+(5*b)+(4*c);
        System.out.println("Resultado: ");
        System.out.println("Mensaje original -> A: "+ a +" B: " + b + " C: " + c);
        System.out.println("Redundancia: -> D: " + d + " E: " + e);
        System.out.println("Mensaje completo -> A: "+ a +" B: " + b + " C: " + c + " D: " + d + " E: " + e);
        
        System.out.println("RECUPERACION DE DATOS");
        System.out.println("¿Cuál de las 3 variables se elimino? (Escribe a, b o c):");
        char variableEliminada = sc.next().toLowerCase().charAt(0);
        
        switch (variableEliminada) {
            case 'a':

                double aRecuperado = (d - b - (3 * c)) / 2.0;
                System.out.println("-> Variable 'a' eliminada.");
                System.out.println("   Valor original: " + a);
                System.out.println("   Valor recuperado (usando D): " + aRecuperado);
                break;
                
            case 'b':

                double bRecuperado = d - (2 * a) - (3 * c);
                System.out.println("-> Variable 'b' eliminada.");
                System.out.println("   Valor original: " + b);
                System.out.println("   Valor recuperado (usando D): " + bRecuperado);
                break;
                
            case 'c':
               
                double cRecuperado = (d - (2 * a) - b) / 3.0;
                System.out.println("-> Variable 'c' eliminada.");
                System.out.println("   Valor original: " + c);
                System.out.println("   Valor recuperado (usando D): " + cRecuperado);
                break;
                
            default:
                System.out.println("Opción no valida. Debes ingresar 'a', 'b' o 'c'.");
                break;
        }
        sc.close();
        }
}